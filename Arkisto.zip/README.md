
# Nordic Energy - Energy Trading Platform

 #### Ethereum Blockchain based application in energy trading.


<pre><a href="https://github.com/nordicenergy/Energy-Trading-Platform">https://github.com/nordicenergy/Energy-Trading-Platform</a></pre>

<pre><a href="https://wwww.nordicenergy.co/Energy-Trading-Platform/NETInfo.php?address=0x4D0A4C762BD7f742096DAAF5911dcf9C94b9ea95">https://www.nordicenergy.co/Energy-Trading-Platform/NETInfo.php?address=0x4D0A4C762BD7f742096DAAF5911dcf9C94b9ea95</a></pre>

<pre><a href="https://wwww.nordicenergy.co/Energy-Trading-Platform/NETInfo.php?address=0x1383b6EFe917e2BB5d80a55a8B1A81f360eD06bd">https://www.nordicenergyy.co/Energy-Trading-Platform/NETInfo.php?address=0x1383b6EFe917e2BB5d80a55a8B1A81f360eD06bd</a></pre>

